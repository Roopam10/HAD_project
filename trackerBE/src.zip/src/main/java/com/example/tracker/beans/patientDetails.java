package com.example.tracker.beans;
import com.example.tracker.utils.SexEnum;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonRootName;
import javax.persistence.*;
import java.util.List;

@Entity

public class patientDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true,nullable = false)
    private Integer id;

    @Column(unique = true)
    private String UHID;
    private String name;
    private Integer age;
    private String sex;

    public patientDetails(Integer id, String UHID, String name, Integer age, String sex) {
        this.id = id;
        this.UHID = UHID;
        this.name = name;
        this.age = age;
        this.sex = sex;
    }

    public patientDetails() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUHID() {
        return UHID;
    }

    public void setUHID(String UHID) {
        this.UHID = UHID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    @Override
    public String toString() {
        return "patientDetails{" +
                "id=" + id +
                ", UHID='" + UHID + '\'' +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", sex='" + sex + '\'' +
                '}';
    }
    //    @Enumerated(EnumType.STRING)
//    private SexEnum sex;
}
