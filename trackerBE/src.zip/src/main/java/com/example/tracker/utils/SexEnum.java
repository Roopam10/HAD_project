package com.example.tracker.utils;

public enum SexEnum {
    MALE,
    FEMALE,
    OTHER
}
