package com.example.tracker.repositories;

import com.example.tracker.beans.patientDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface patientDetailsRepository extends JpaRepository<patientDetails,Integer> {
   // patientDetails findByUHID(String id);
    @Query(
            value = "SELECT * FROM patient_details u WHERE u.id = ?1",
            nativeQuery = true)
    patientDetails getById1(Integer id);
}
